Once you have downloaded the Zip file, it should be extracted into your Arduino Libraries folder and the folder renamed to "LEDText".

For full instructions see the Wiki icon on the right.

Update December 2021
I have added a quickly hacked together Font Generator that I made a long time ago. It allows you to use any font on your Windows system
to generate a font header file for use with my LEDText class. I don't plan to develop this any more and be warned it can be glitchy.
It should be fairly easy to work out. Once the font is generated it needs to be copied from the text window into a file.
